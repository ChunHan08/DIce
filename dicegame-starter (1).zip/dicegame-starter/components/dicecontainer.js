import React from 'react'
import { View, Text, Image, StyleSheet } from 'react-native'
import Button from './button'
import randomNumGenerator from './lib/dicegenerator'

export default function Comp() {
  return <></>
}

const styles = StyleSheet.create({})

const dicearr = [
  require('../assets/dice/dice-1.png'),
  require('../assets/dice/dice-2.png'),
  require('../assets/dice/dice-3.png'),
  require('../assets/dice/dice-4.png'),
  require('../assets/dice/dice-5.png'),
  require('../assets/dice/dice-6.png'),
]
